import React from 'react';

function About(){
    return(
        <div>
            <h1 align="left">Dog</h1>
            <img src="assets/images/dog.jpg"></img>
            <h3>The dog has been selectively bred over millennia for various behaviors, sensory capabilities, and physical attributes.</h3>
            <h1 align="left">Cat</h1>
            <img src="assets/images/cat.jpg"></img>
            <h3>The cat is similar in anatomy to the other felid species.</h3>
            <h1 align="left">Lion</h1>
            <img src="assets/images/lion.jpg"></img>
            <h3>The lion (Panthera leo) is a large felid of the genus Panthera native mainly to Africa.</h3>
        </div>
    )
}
export default About;