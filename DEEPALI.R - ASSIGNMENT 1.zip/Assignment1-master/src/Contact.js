import React from 'react';

function Contact(){
    return(
        <div>
            <h1 align='center'>Assignment 1</h1>
            <h3>Name:Asmitha M</h3>
            <h3>Id no:20181CSE0080</h3>
        </div>
    )
}
export default Contact;