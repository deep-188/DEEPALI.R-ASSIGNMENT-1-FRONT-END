import React from 'react';


function Home(props){
    return(
        <div>
            <h1>Dog</h1>
            <img src="assets/images/dog2.jpg"></img>
            <h2 align="center">Id: 01</h2>
            <h2 align="center">Section: 05</h2>
            <h1>Cat</h1>
            <img src="assets/images/cat2.jpg"></img>
            <h2 align="center">Id: 02</h2>
            <h2 align="center">Section: 01</h2>
            <h1>Lion</h1>
            <img src="assets/images/lion2.jpg"></img>
            <h2 align="center">Id: 03</h2>
            <h2 align="center">Section: 04</h2>
        </div>
    )
}
export default Home;